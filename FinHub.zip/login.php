<?php
include 'db.php'; // Veritabanı bağlantısı ve session_start burada olmalı

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$user]);
    $res = $stmt->fetch();

    if ($res && password_verify($pass, $res['password'])) {
        
        // --- KRİTİK KONTROL: HESAP ASKIYA ALINMIŞ MI? ---
        if (isset($res['status']) && $res['status'] == 'suspended') {
            $error = "Erişim Reddedildi: Hesabınız yöneticiniz tarafından askıya alınmıştır!";
        } else {
            $_SESSION['user_id'] = $res['id'];
            $_SESSION['username'] = $res['username'];
            header("Location: index.php");
            exit();
        }
        
    } else {
        $error = "Bilgiler hatalı, tekrar dene reis.";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">
    <title>FinHub | Giriş</title>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #000; overflow: hidden; }
        .mesh-gradient {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.15) 0, transparent 50%), 
                        radial-gradient(at 100% 100%, rgba(168, 85, 247, 0.15) 0, transparent 50%);
            z-index: -1;
        }
        .glass-input { background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.1); transition: all 0.3s ease; }
        .glass-input:focus { border-color: #6366f1; background: rgba(255, 255, 255, 0.07); outline: none; }
    </style>
</head>
<body class="flex items-center justify-center h-screen">
    <div class="mesh-gradient"></div>
    
    <div class="w-full max-w-md p-8 animate-in fade-in zoom-in duration-700">
        <div class="text-center mb-10">
            <div class="inline-block p-4 rounded-3xl bg-indigo-600/20 mb-4 border border-indigo-500/30">
                <svg class="w-10 h-10 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                </svg>
            </div>
            <h1 class="text-4xl font-extrabold text-white tracking-tight">Fin<span class="text-indigo-500">Hub</span></h1>
            <p class="text-gray-400 mt-2 italic font-medium">Finansın geleceği.</p>
        </div>

        <?php if($error): ?>
            <div class="bg-red-500/10 border border-red-500/50 text-red-500 p-4 rounded-xl text-center mb-6 text-sm font-bold italic animate-bounce">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php" class="space-y-4">
            <div>
                <input type="text" name="username" required 
                    class="glass-input w-full p-4 rounded-2xl text-white placeholder-gray-500 font-bold" 
                    placeholder="Kullanıcı Adı">
            </div>
            <div>
                <input type="password" name="password" required 
                    class="glass-input w-full p-4 rounded-2xl text-white placeholder-gray-500 font-bold" 
                    placeholder="Şifre">
            </div>
            <button type="submit" 
                class="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-black uppercase italic rounded-2xl transition-all shadow-xl shadow-indigo-600/20 active:scale-95">
                Giriş Yap
            </button>
        </form>
    </div>
</body>
</html>