<?php
mb_internal_encoding("UTF-8");
header('Content-Type: text/html; charset=utf-8');
session_start();

try {
    $pdo = new PDO("mysql:host=localhost;dbname=mustafem_finans;charset=utf8mb4", "mustafem_finans", "002014Ae*-");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_turkish_ci");
} catch(PDOException $e) { die("Hata: " . $e->getMessage()); }

function checkAuth() { if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); } }
?>