<?php
include 'db.php';
checkAuth();
$uid = $_SESSION['user_id'];

// Dosya adını ayarla (Örn: FinHub_Rapor_2026-01-02.xls)
$filename = "FinHub_Rapor_" . date('Y-m-d') . ".xls";

// Tarayıcıya bunun bir excel dosyası olduğunu söylüyoruz
header("Content-Type: application/vnd.ms-excel; charset=UTF-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");

// UTF-8 karakter sorunu olmaması için (Türkçe karakterler için şart)
echo "\xEF\xBB\xBF"; 

// Verileri çek
$stmt = $pdo->prepare("SELECT tarih, type, category, amount FROM transactions WHERE user_id = ? ORDER BY tarih DESC");
$stmt->execute([$uid]);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Excel Tablo Başlıkları
echo "<table border='1'>";
echo "<tr style='background-color: #4f46e5; color: white;'>
        <th>Tarih</th>
        <th>Tür</th>
        <th>Kategori</th>
        <th>Miktar (TL)</th>
      </tr>";

// Verileri satır satır yazdır
foreach ($data as $row) {
    $tarih = date('d.m.Y', strtotime($row['tarih']));
    $tur = ucfirst($row['type']);
    $kategori = htmlspecialchars($row['category']);
    $miktar = number_format($row['amount'], 2, ',', '.');

    echo "<tr>
            <td>$tarih</td>
            <td>$tur</td>
            <td>$kategori</td>
            <td>$miktar</td>
          </tr>";
}
echo "</table>";
exit;