<?php 
date_default_timezone_set('Europe/Istanbul');
include 'db.php'; 
checkAuth(); 
$uid = $_SESSION['user_id'];

// --- KULLANICI BİLGİLERİ ---
$me = $pdo->prepare("SELECT id, shared_id, full_name, username FROM users WHERE id = ?");
$me->execute([$uid]);
$user_me = $me->fetch();
$view_id = ($user_me['shared_id'] > 0) ? $user_me['shared_id'] : $uid;
$my_name = $user_me['full_name']; 

// --- KULLANICI EKLEME İŞLEMİ ---
if (isset($_POST['add_new_user'])) {
    $fn = $_POST['u_fullname'];
    $u  = $_POST['u_name'];
    $p  = password_hash($_POST['u_pass'], PASSWORD_DEFAULT);
    $shared_id = ($_POST['u_share'] == "1") ? $uid : 0; 
    
    $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $check->execute([$u]);
    if ($check->rowCount() == 0) {
        $pdo->prepare("INSERT INTO users (full_name, username, password, shared_id, status) VALUES (?, ?, ?, ?, 'active')")
            ->execute([$fn, $u, $p, $shared_id]);
        header("Location: index.php?msg=Kullanıcı Eklendi"); exit();
    } else {
        header("Location: index.php?msg=Hata: Kullanıcı adı mevcut!"); exit();
    }
}

// --- PROFİL GÜNCELLEME ---
if (isset($_POST['update_profile'])) {
    $n_fn = $_POST['n_fullname'];
    if(!empty($_POST['n_password'])) {
        $pdo->prepare("UPDATE users SET full_name=?, password=? WHERE id=?")
            ->execute([$n_fn, password_hash($_POST['n_password'], PASSWORD_DEFAULT), $uid]);
    } else {
        $pdo->prepare("UPDATE users SET full_name=? WHERE id=?")->execute([$n_fn, $uid]);
    }
    header("Location: index.php?msg=Profil Güncellendi"); exit();
}

// --- İŞLEM KAYIT ---
if (isset($_POST['save'])) {
    if (!empty($_POST['id'])) { 
        $pdo->prepare("UPDATE transactions SET type=?, category=?, amount=?, tarih=? WHERE id=? AND user_id=?")
            ->execute([$_POST['type'], $_POST['category'], $_POST['amount'], $_POST['tarih'], $_POST['id'], $view_id]); 
    } else { 
        $pdo->prepare("INSERT INTO transactions (user_id, type, category, amount, tarih, added_by) VALUES (?,?,?,?,?,?)")
            ->execute([$view_id, $_POST['type'], $_POST['category'], $_POST['amount'], $_POST['tarih'], $my_name]); 
    }
    header("Location: index.php"); exit();
}

// --- SİLME İŞLEMLERİ ---
if (isset($_GET['del'])) { $pdo->prepare("DELETE FROM transactions WHERE id=? AND user_id=?")->execute([$_GET['del'], $view_id]); header("Location: index.php"); exit(); }
if (isset($_GET['del_partner'])) {
    $pdo->prepare("DELETE FROM users WHERE id = ? AND shared_id = ?")->execute([$_GET['del_partner'], $uid]);
    header("Location: index.php?msg=Ortak hesap silindi"); exit();
}

// VERİLER
$stats = $pdo->query("SELECT SUM(CASE WHEN type='gelir' THEN amount ELSE 0 END) as gelir, SUM(CASE WHEN type='gider' THEN amount ELSE 0 END) as gider FROM transactions WHERE user_id = $view_id")->fetch();
$bakiye = ($stats['gelir'] ?? 0) - ($stats['gider'] ?? 0);
$history = $pdo->query("SELECT * FROM transactions WHERE user_id = $view_id ORDER BY tarih DESC LIMIT 20")->fetchAll();
$msg = $_GET['msg'] ?? "";
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <title>FinHub | Panel</title>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #02040a; color: #fff; overflow-x: hidden; }
        .glass { background: rgba(255,255,255,0.02); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.08); }
        .modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.95); z-index: 1000; align-items: center; justify-content: center; padding: 15px; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: #4f46e5; border-radius: 10px; }
        select option { background: #02040a; color: white; }
        
        /* MOBİL TABLO DÜZENİ */
        @media (max-width: 768px) {
            .responsive-table thead { display: none; }
            .responsive-table tr { 
                display: block; 
                margin-bottom: 1.5rem; 
                padding: 1.25rem; 
                background: rgba(255,255,255,0.03); 
                border-radius: 1.5rem; 
                border: 1px solid rgba(255,255,255,0.05); 
            }
            .responsive-table td { 
                display: flex; 
                justify-content: space-between; 
                align-items: center; 
                padding: 0.6rem 0; 
                border: none !important; 
                width: 100%;
            }
            .responsive-table td::before { 
                content: attr(data-label); 
                font-size: 10px; 
                font-weight: 800; 
                text-transform: uppercase; 
                color: #6366f1; 
            }
            .responsive-table td:last-child {
                margin-top: 0.5rem;
                padding-top: 1rem;
                border-top: 1px solid rgba(255,255,255,0.05) !important;
                justify-content: center;
                gap: 15px;
            }
        }
    </style>
</head>
<body class="flex flex-col md:flex-row min-h-screen">

    <nav class="md:hidden fixed bottom-0 left-0 right-0 glass z-50 flex justify-around p-4 border-t border-white/10">
        <a href="index.php" class="text-indigo-500"><i data-lucide="layout-grid"></i></a>
        <a href="analiz.php" class="text-gray-400"><i data-lucide="line-chart"></i></a>
        <a href="defter.php" class="text-gray-400"><i data-lucide="book-open"></i></a>
        <button onclick="openModal('addUserModal')" class="text-gray-400"><i data-lucide="user-plus"></i></button>
    </nav>

    <aside class="hidden md:flex w-64 border-r border-white/10 p-6 flex-col h-screen sticky top-0 bg-[#02040a]">
        <div class="text-3xl font-black text-indigo-500 italic mb-10 flex items-center gap-2"><i data-lucide="zap"></i> FinHub.</div>
        <nav class="flex-1 space-y-3">
            <a href="index.php" class="flex items-center gap-3 p-4 bg-indigo-600 rounded-2xl text-white shadow-lg font-bold italic transition"><i data-lucide="layout-grid"></i> Panel</a>
            <a href="analiz.php" class="flex items-center gap-3 p-4 text-gray-400 hover:text-white transition font-medium"><i data-lucide="line-chart"></i> Akıllı Analiz</a>
            <a href="defter.php" class="flex items-center gap-3 p-4 text-gray-400 hover:text-white transition font-medium"><i data-lucide="book-open"></i> Borç Defteri</a>
            
            <div class="pt-6 mt-6 border-t border-white/10 space-y-2">
                <button onclick="openModal('userSettingsModal')" class="w-full flex items-center gap-3 p-4 text-gray-400 hover:text-white transition font-bold italic text-sm text-left"><i data-lucide="settings"></i> Profil Ayarları</button>
                <button onclick="openModal('addUserModal')" class="w-full flex items-center gap-3 p-4 text-emerald-400 hover:bg-emerald-500/10 rounded-2xl transition font-bold italic text-sm text-left"><i data-lucide="user-plus"></i> Kullanıcı Ekle</button>
                <button onclick="openModal('managePartnersModal')" class="w-full flex items-center gap-3 p-4 text-amber-400 hover:bg-amber-500/10 rounded-2xl transition font-bold italic text-sm text-left"><i data-lucide="users"></i> Ortakları Yönet</button>
            </div>
        </nav>
        <div class="mt-auto pt-6 border-t border-white/5 text-[10px] text-gray-600 font-bold uppercase tracking-widest italic">Mustafa Karakoç © 2026</div>
    </aside>

    <main class="flex-1 p-4 md:p-10 pb-28 md:pb-10 overflow-x-hidden">
        <div class="mb-10 flex justify-between items-center gap-4">
            <div class="truncate">
                <p class="text-gray-500 text-[8px] md:text-[10px] font-black uppercase tracking-[0.2em] mb-1 italic">Finansal Kontrol Merkezi</p>
                <h1 class="text-xl md:text-4xl font-black italic tracking-tighter uppercase text-white truncate">
                    HOŞGELDİN, <span class="text-indigo-500"><?php echo htmlspecialchars($my_name); ?></span>
                </h1>
            </div>
            <div class="flex gap-2 shrink-0">
                <a href="export.php" class="p-3 md:p-5 glass rounded-2xl text-emerald-500 border border-emerald-500/10"><i data-lucide="file-spreadsheet"></i></a>
                <a href="logout.php" class="p-3 md:p-5 glass rounded-2xl text-red-500 border border-red-500/10"><i data-lucide="log-out"></i></a>
            </div>
        </div>

        <?php if($msg): ?>
            <div class="bg-indigo-500/10 text-indigo-400 p-4 rounded-2xl mb-8 text-center text-sm font-bold border border-indigo-500/20 shadow-xl"><?php echo $msg; ?></div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-10">
            <div class="glass p-6 md:p-8 rounded-[2rem] border-l-4 border-indigo-600">
                <span class="text-[10px] text-gray-500 font-bold uppercase italic tracking-wider">Net Bakiye</span>
                <h2 class="text-2xl md:text-3xl font-black mt-2 italic">₺<?php echo number_format($bakiye, 2, ',', '.'); ?></h2>
            </div>
            <div class="glass p-6 md:p-8 rounded-[2rem] border-l-4 border-emerald-500">
                <span class="text-[10px] text-emerald-500 font-bold uppercase italic tracking-wider">Toplam Gelir</span>
                <h2 class="text-2xl md:text-3xl font-black mt-2 text-emerald-400 italic">₺<?php echo number_format($stats['gelir'] ?? 0, 2, ',', '.'); ?></h2>
            </div>
            <div class="glass p-6 md:p-8 rounded-[2rem] border-l-4 border-red-500">
                <span class="text-[10px] text-red-500 font-bold uppercase italic tracking-wider">Toplam Gider</span>
                <h2 class="text-2xl md:text-3xl font-black mt-2 text-red-400 italic">₺<?php echo number_format($stats['gider'] ?? 0, 2, ',', '.'); ?></h2>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div class="lg:col-span-4 glass p-6 md:p-8 rounded-[2rem] h-fit">
                <h3 id="fTitle" class="text-lg md:text-xl font-black mb-6 italic text-indigo-400 uppercase flex items-center gap-2"><i data-lucide="plus-circle"></i> İşlem Ekle</h3>
                <form method="POST" id="mainForm" class="space-y-4">
                    <input type="hidden" name="id" id="eId">
                    <div class="grid grid-cols-1 gap-4">
                        <select name="type" id="eType" class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                            <option value="gider">Gider</option>
                            <option value="gelir">Gelir</option>
                        </select>
                        <input type="date" name="tarih" id="eDate" value="<?php echo date('Y-m-d'); ?>" class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                    </div>
                    <input type="text" name="category" id="eCat" placeholder="Kategori (Örn: Kira, Maaş)" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold italic outline-none focus:border-indigo-500 transition-all">
                    <input type="number" name="amount" id="eAmt" step="0.01" placeholder="0,00 ₺" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-black text-xl outline-none focus:border-indigo-500 transition-all">
                    <button type="submit" name="save" class="w-full py-5 bg-indigo-600 rounded-2xl font-black uppercase italic text-white shadow-lg hover:bg-indigo-500 transition-all">Sisteme İşle</button>
                    <button type="button" onclick="resetForm()" id="cBtn" class="hidden w-full text-[10px] text-gray-500 font-bold uppercase mt-2 text-center underline">İptal ve Sıfırla</button>
                </form>
            </div>

            <div class="lg:col-span-8 glass p-4 md:p-8 rounded-[2rem]">
                <div class="overflow-hidden">
                    <table class="w-full text-left responsive-table">
                        <thead>
                            <tr class="text-gray-600 text-[10px] uppercase font-black border-b border-white/5">
                                <th class="pb-4 px-2">Detaylar</th>
                                <th class="pb-4 text-right">Tutar</th>
                                <th class="pb-4 text-center">Yönet</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-white/5">
                            <?php foreach($history as $h): ?>
                            <tr class="hover:bg-white/[0.01] transition">
                                <td class="py-4 px-2" data-label="İşlem">
                                    <div class="font-bold uppercase italic text-white text-sm"><?php echo htmlspecialchars($h['category']); ?></div>
                                    <div class="text-[9px] text-gray-500 font-bold mt-1 uppercase"><?php echo date('d.m.y', strtotime($h['tarih'])); ?> | <span class="text-indigo-400"><?php echo $h['added_by']; ?></span></div>
                                </td>
                                <td class="py-4 text-right font-black" data-label="Tutar">
                                    <span class="<?php echo $h['type']=='gelir' ? 'text-emerald-500' : 'text-red-500'; ?>">
                                        <?php echo $h['type']=='gelir' ? '+' : '-'; ?> ₺<?php echo number_format($h['amount'], 2, ',', '.'); ?>
                                    </span>
                                </td>
                                <td class="py-4 text-center" data-label="Eylem">
                                    <div class="flex justify-center gap-2">
                                        <button onclick='edit(<?php echo json_encode($h); ?>)' class="p-3 bg-indigo-500/10 rounded-xl text-indigo-400 hover:bg-indigo-600 hover:text-white transition"><i data-lucide="pencil" class="w-4 h-4"></i></button>
                                        <a href="?del=<?php echo $h['id']; ?>" onclick="return confirm('Silinsin mi?')" class="p-3 bg-red-500/10 rounded-xl text-red-500 hover:bg-red-600 hover:text-white transition"><i data-lucide="trash-2" class="w-4 h-4"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <div id="addUserModal" class="modal">
        <div class="glass p-6 md:p-8 rounded-[2.5rem] w-full max-w-md overflow-y-auto max-h-[90vh]"> 
            <h3 class="text-xl font-black mb-6 text-emerald-500 text-center uppercase italic tracking-tighter">Yeni Ortak / Kullanıcı</h3>
            <form method="POST" action="index.php" class="space-y-4"> 
                <input type="text" name="u_fullname" placeholder="Ad Soyad" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold outline-none">
                <input type="text" name="u_name" placeholder="Kullanıcı Adı" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold outline-none">
                <input type="password" name="u_pass" placeholder="Şifre" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold outline-none">
                <select name="u_share" class="w-full p-4 bg-white/10 border border-white/20 rounded-2xl text-white font-bold">
                     <option value="1">Ortak (Verileri Görür)</option>
                     <option value="0">Bağımsız (Yalnızca Kendini Görür)</option>
                </select>
                <button type="submit" name="add_new_user" class="w-full py-4 bg-emerald-600 rounded-2xl font-black uppercase italic text-white shadow-lg">Kaydı Tamamla</button>
                <button type="button" onclick="closeModal('addUserModal')" class="w-full py-2 text-gray-500 font-bold uppercase text-[10px]">Vazgeç</button>
            </form>
        </div>
    </div>

    <div id="userSettingsModal" class="modal">
        <div class="glass p-8 rounded-[2.5rem] w-full max-w-sm">
            <h3 class="text-xl font-black mb-6 text-indigo-500 text-center uppercase italic">Profil Ayarları</h3>
            <form method="POST" action="index.php" class="space-y-4">
                <input type="text" name="n_fullname" value="<?php echo htmlspecialchars($my_name); ?>" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold">
                <input type="password" name="n_password" placeholder="Yeni Şifre (Boş bırakılabilir)" class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold">
                <button type="submit" name="update_profile" class="w-full py-4 bg-indigo-600 rounded-2xl font-black uppercase italic">Güncelle</button>
                <button type="button" onclick="closeModal('userSettingsModal')" class="w-full py-2 text-gray-500 font-bold uppercase text-[10px]">Kapat</button>
            </form>
        </div>
    </div>

    <div id="managePartnersModal" class="modal">
        <div class="glass p-6 md:p-8 rounded-[2.5rem] w-full max-w-md max-h-[80vh] overflow-y-auto">
            <h3 class="text-xl font-black mb-6 text-amber-500 text-center uppercase italic">Ortakları Yönet</h3>
            <div class="space-y-3">
                <?php
                $stmt = $pdo->prepare("SELECT * FROM users WHERE shared_id = ?");
                $stmt->execute([$uid]);
                $partners = $stmt->fetchAll();
                foreach ($partners as $p): ?>
                    <div class="p-4 bg-white/5 rounded-2xl border border-white/10 flex items-center justify-between">
                        <span class="font-bold text-sm"><?php echo htmlspecialchars($p['full_name']); ?></span>
                        <a href="?del_partner=<?php echo $p['id']; ?>" onclick="return confirm('Bu hesabı silmek istediğine emin misin?')" class="p-2 bg-red-500/10 text-red-500 rounded-xl"><i data-lucide="trash-2" class="w-4 h-4"></i></a>
                    </div>
                <?php endforeach; if(empty($partners)) echo "<p class='text-center text-gray-500 text-sm italic py-4'>Henüz ortak hesap yok.</p>"; ?>
            </div>
            <button onclick="closeModal('managePartnersModal')" class="w-full mt-6 py-4 glass rounded-2xl font-bold uppercase text-[10px]">Kapat</button>
        </div>
    </div>

    <script>
        lucide.createIcons();
        function openModal(id) { document.getElementById(id).style.display = 'flex'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }
        
        function edit(i) {
            document.getElementById('fTitle').innerText = "Düzenleniyor...";
            document.getElementById('eId').value = i.id;
            document.getElementById('eType').value = i.type;
            document.getElementById('eCat').value = i.category;
            document.getElementById('eAmt').value = i.amount;
            document.getElementById('eDate').value = i.tarih;
            document.getElementById('cBtn').classList.remove('hidden');
            window.scrollTo({top: 0, behavior: 'smooth'});
        }
        
        function resetForm() {
            document.getElementById('mainForm').reset();
            document.getElementById('eId').value = "";
            document.getElementById('cBtn').classList.add('hidden');
            document.getElementById('fTitle').innerText = "İşlem Ekle";
        }
        
        window.onclick = function(e) { if(e.target.classList.contains('modal')) closeModal(e.target.id); }
    </script>
</body>
</html>