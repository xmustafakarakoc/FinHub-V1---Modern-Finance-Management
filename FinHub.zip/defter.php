<?php 
date_default_timezone_set('Europe/Istanbul');
include 'db.php'; 
checkAuth(); 
$uid = $_SESSION['user_id'];

// --- KULLANICI BİLGİLERİ VE ORTAK HESAP KONTROLÜ ---
$me = $pdo->prepare("SELECT id, shared_id, full_name, username FROM users WHERE id = ?");
$me->execute([$uid]);
$user_me = $me->fetch();
$view_id = ($user_me['shared_id'] > 0) ? $user_me['shared_id'] : $uid;
$my_name = $user_me['full_name']; // Karşılama için tam isim

$msg = isset($_GET['msg']) ? $_GET['msg'] : "";

// --- KULLANICI YÖNETİMİ ---
if (isset($_POST['add_new_user'])) {
    $fn = $_POST['u_fullname'];
    $u  = $_POST['u_name'];
    $p  = password_hash($_POST['u_pass'], PASSWORD_DEFAULT);
    $shared_id = ($_POST['u_share'] == "1") ? $uid : 0; 

    $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $check->execute([$u]);
    if ($check->rowCount() == 0) {
        $pdo->prepare("INSERT INTO users (full_name, username, password, shared_id, status) VALUES (?, ?, ?, ?, 'active')")->execute([$fn, $u, $p, $shared_id]);
        header("Location: defter.php?msg=Yeni kullanıcı ($fn) eklendi!"); exit();
    } else { $msg = "Bu kullanıcı zaten mevcut!"; }
}

if (isset($_POST['update_profile'])) {
    $n_fn = $_POST['n_fullname'];
    $n_u  = $_POST['n_username'];
    $n_p  = $_POST['n_password'];
    if(!empty($n_p)) {
        $hashed = password_hash($n_p, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET full_name=?, username=?, password=? WHERE id=?")->execute([$n_fn, $n_u, $hashed, $uid]);
    } else {
        $pdo->prepare("UPDATE users SET full_name=?, username=? WHERE id=?")->execute([$n_fn, $n_u, $uid]);
    }
    header("Location: defter.php?msg=Profil güncellendi!"); exit();
}

if (isset($_GET['toggle_status'])) {
    $target_id = $_GET['toggle_status'];
    $new_status = $_GET['st'] == 'active' ? 'suspended' : 'active';
    $check = $pdo->prepare("SELECT id FROM users WHERE id = ? AND shared_id = ?");
    $check->execute([$target_id, $uid]);
    if ($check->rowCount() > 0) {
        $pdo->prepare("UPDATE users SET status = ? WHERE id = ?")->execute([$new_status, $target_id]);
        header("Location: defter.php?msg=Durum Güncellendi"); exit();
    }
}

if (isset($_GET['del_partner'])) {
    $target_id = $_GET['del_partner'];
    $check = $pdo->prepare("SELECT id FROM users WHERE id = ? AND shared_id = ?");
    $check->execute([$target_id, $uid]);
    if ($check->rowCount() > 0) {
        $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$target_id]);
        header("Location: defter.php?msg=Ortak hesap silindi"); exit();
    }
}

// --- BORÇ / ALACAK KAYIT ---
if (isset($_POST['save_debt'])) {
    $t = $_POST['title'];
    $a = $_POST['amount'];
    $type = $_POST['type']; 
    $date = $_POST['due_date'];

    if (!empty($_POST['id'])) { 
        $pdo->prepare("UPDATE debts SET title=?, amount=?, type=?, due_date=? WHERE id=? AND user_id=?")->execute([$t, $a, $type, $date, $_POST['id'], $view_id]); 
    } else { 
        $pdo->prepare("INSERT INTO debts (user_id, title, amount, type, due_date, status) VALUES (?,?,?,?,?,'active')")->execute([$view_id, $t, $a, $type, $date]); 
    }
    header("Location: defter.php"); exit();
}

// --- BORÇ KAPATMA VE KASAYA AKTARMA ---
if (isset($_GET['close'])) {
    $did = $_GET['close'];
    $stmt = $pdo->prepare("SELECT * FROM debts WHERE id=? AND user_id=?");
    $stmt->execute([$did, $view_id]);
    $debt = $stmt->fetch();

    if ($debt) {
        $pdo->prepare("UPDATE debts SET status='closed' WHERE id=?")->execute([$did]);
        $t_type = ($debt['type'] == 'alacak') ? 'gelir' : 'gider';
        $t_cat = ($debt['type'] == 'alacak') ? "Borç Tahsilatı" : "Borç Ödemesi";
        $t_desc = htmlspecialchars($debt['title']) . " - Borç Kapatma";
        
        $pdo->prepare("INSERT INTO transactions (user_id, type, category, amount, tarih) VALUES (?, ?, ?, ?, CURDATE())")
            ->execute([$view_id, $t_type, $t_cat . " (" . $t_desc . ")", $debt['amount']]);
            
        header("Location: defter.php?msg=Borç kapatıldı ve kasaya işlendi!"); exit();
    }
}

if (isset($_GET['del'])) { $pdo->prepare("DELETE FROM debts WHERE id=? AND user_id=?")->execute([$_GET['del'], $view_id]); header("Location: defter.php"); exit(); }

// VERİLER
$debts = $pdo->query("SELECT *, DATEDIFF(due_date, CURDATE()) as kalan_gun FROM debts WHERE user_id = $view_id AND status='active' ORDER BY due_date ASC")->fetchAll();
$d_stats = $pdo->query("SELECT SUM(CASE WHEN type='alacak' THEN amount ELSE 0 END) as alacak, SUM(CASE WHEN type='borc' THEN amount ELSE 0 END) as borc FROM debts WHERE user_id = $view_id AND status='active'")->fetch();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <title>FinHub | Borç Defteri</title>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #02040a; color: #fff; overflow-x: hidden; }
        .glass { background: rgba(255,255,255,0.02); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.08); }
        .modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.95); z-index: 1000; align-items: center; justify-content: center; padding: 15px; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: #4f46e5; border-radius: 10px; }
        .vade-alarm { position: absolute; left: 0; top: 0; bottom: 0; width: 4px; background: #ef4444; box-shadow: 0 0 15px #ef4444; animation: pulse 2s infinite; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.3; } 100% { opacity: 1; } }
        select option { background-color: #02040a !important; color: white !important; }
    </style>
</head>
<body class="flex flex-col md:flex-row min-h-screen">

    <nav class="md:hidden fixed bottom-0 left-0 right-0 glass z-50 flex justify-around p-4 border-t border-white/10">
        <a href="index.php" class="text-gray-400"><i data-lucide="layout-grid"></i></a>
        <a href="analiz.php" class="text-gray-400"><i data-lucide="line-chart"></i></a>
        <a href="defter.php" class="text-indigo-500"><i data-lucide="book-open"></i></a>
        <button onclick="openModal('managePartnersModal')" class="text-amber-400"><i data-lucide="users"></i></button>
    </nav>

    <aside class="hidden md:flex w-64 border-r border-white/10 p-6 flex-col h-screen sticky top-0 bg-[#02040a]">
        <div class="text-3xl font-black text-indigo-500 italic mb-10 flex items-center gap-2"><i data-lucide="zap"></i> FinHub.</div>
        <nav class="flex-1 space-y-3">
            <a href="index.php" class="flex items-center gap-3 p-4 text-gray-400 hover:text-white transition font-medium"><i data-lucide="layout-grid"></i> Panel</a>
            <a href="analiz.php" class="flex items-center gap-3 p-4 text-gray-400 hover:text-white transition font-medium"><i data-lucide="line-chart"></i> Akıllı Analiz</a>
            <a href="defter.php" class="flex items-center gap-3 p-4 bg-indigo-600 rounded-2xl text-white shadow-lg font-bold italic transition"><i data-lucide="book-open"></i> Borç Defteri</a>
            
            <div class="pt-6 mt-6 border-t border-white/10 space-y-2">
                <button onclick="openModal('userSettingsModal')" class="w-full flex items-center gap-3 p-4 text-gray-400 hover:text-white transition font-bold italic text-sm text-left"><i data-lucide="settings"></i> Profil Ayarları</button>
                <button onclick="openModal('addUserModal')" class="w-full flex items-center gap-3 p-4 text-emerald-400 hover:bg-emerald-500/10 rounded-2xl transition font-bold italic text-sm text-left"><i data-lucide="user-plus"></i> Kullanıcı Ekle</button>
                <button onclick="openModal('managePartnersModal')" class="w-full flex items-center gap-3 p-4 text-amber-400 hover:bg-amber-500/10 rounded-2xl transition font-bold italic text-sm text-left"><i data-lucide="users"></i> Ortakları Yönet</button>
            </div>
        </nav>
        <div class="mt-auto pt-6 border-t border-white/5 text-[10px] text-gray-600 font-bold uppercase tracking-widest leading-relaxed">Mustafa Karakoç © 2026</div>
    </aside>

    <main class="flex-1 p-4 md:p-10 pb-28 md:pb-10">
        <div class="mb-10 flex justify-between items-center">
            <div>
                <p class="text-gray-500 text-[8px] md:text-[10px] font-black uppercase tracking-[0.3em] mb-1 italic">Borç ve Alacak Takip Sistemi</p>
                <h1 class="text-2xl md:text-3xl font-black italic uppercase text-white">
                    HOŞGELDİN, <span class="text-indigo-500"><?php echo htmlspecialchars($my_name); ?></span>
                </h1>
            </div>
            <div class="flex gap-2">
                <a href="export.php" class="p-3 md:p-5 glass rounded-2xl text-emerald-500 hover:bg-emerald-500/10 transition border border-emerald-500/10" title="Excel Raporu Al">
                    <i data-lucide="file-spreadsheet"></i>
                </a>
                <a href="logout.php" class="p-3 md:p-5 glass rounded-2xl text-red-500 hover:bg-red-500/10 transition border border-red-500/10" title="Güvenli Çıkış">
                    <i data-lucide="log-out"></i>
                </a>
            </div>
        </div>

        <?php if($msg) echo "<div class='bg-indigo-500/10 text-indigo-400 p-4 rounded-2xl mb-8 text-center text-sm font-bold border border-indigo-500/20 shadow-xl'>$msg</div>"; ?>

        <div class="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8 mb-10">
            <div class="glass p-5 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] border-l-4 border-emerald-500">
                <span class="text-[8px] md:text-[10px] text-emerald-500 font-bold uppercase italic tracking-widest">Alacak</span>
                <h2 class="text-lg md:text-3xl font-black mt-1 italic text-emerald-400">₺<?php echo number_format($d_stats['alacak'] ?? 0, 2, ',', '.'); ?></h2>
            </div>
            <div class="glass p-5 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] border-l-4 border-red-500">
                <span class="text-[8px] md:text-[10px] text-red-500 font-bold uppercase italic tracking-widest">Borç</span>
                <h2 class="text-lg md:text-3xl font-black mt-1 italic text-red-400">₺<?php echo number_format($d_stats['borc'] ?? 0, 2, ',', '.'); ?></h2>
            </div>
            <div class="col-span-2 md:col-span-1 glass p-5 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] border-l-4 border-indigo-600">
                <span class="text-[8px] md:text-[10px] text-indigo-500 font-bold uppercase italic tracking-widest">Net Durum</span>
                <h2 class="text-lg md:text-3xl font-black mt-1 italic">₺<?php echo number_format(($d_stats['alacak'] - $d_stats['borc']), 2, ',', '.'); ?></h2>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div class="lg:col-span-4 glass p-6 md:p-8 rounded-[2rem] h-fit">
                <h3 id="fTitle" class="text-lg font-black mb-6 italic text-indigo-400 uppercase flex items-center gap-2"><i data-lucide="plus-circle"></i> Kayıt Ekle</h3>
                <form method="POST" id="mainForm" class="space-y-4">
                    <input type="hidden" name="id" id="eId">
                    <select name="type" id="eType" class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                        <option value="alacak">Alacağım Var (+ Gelir)</option>
                        <option value="borc">Borcum Var (- Gider)</option>
                    </select>
                    <input type="text" name="title" id="eTitle" placeholder="Kişi veya Açıklama" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                    <input type="number" name="amount" id="eAmt" step="0.01" placeholder="Miktar (₺)" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-black text-sm">
                    <input type="date" name="due_date" id="eDate" value="<?php echo date('Y-m-d'); ?>" class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                    <button type="submit" name="save_debt" class="w-full py-4 bg-indigo-600 rounded-2xl font-black uppercase italic text-sm tracking-widest text-white hover:bg-indigo-500 transition-all">Deftere İşle</button>
                    <button type="button" onclick="resetForm()" id="cBtn" class="hidden w-full text-[10px] text-gray-500 font-bold uppercase mt-2 text-center underline">Değişiklikten Vazgeç</button>
                </form>
            </div>

            <div class="lg:col-span-8 glass p-6 md:p-8 rounded-[2rem]">
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead>
                            <tr class="text-gray-600 text-[10px] uppercase font-black border-b border-white/5">
                                <th class="pb-4 pl-4">Durum</th>
                                <th class="pb-4">Açıklama / Vade</th>
                                <th class="pb-4 text-right">Tutar</th>
                                <th class="pb-4 text-center">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-white/5">
                            <?php foreach($debts as $d): $is_critical = ($d['kalan_gun'] <= 3); ?>
                            <tr class="group relative hover:bg-white/[0.01]">
                                <td class="py-6 pl-4 text-center relative">
                                    <?php if($is_critical) echo '<div class="vade-alarm"></div>'; ?>
                                    <i data-lucide="<?php echo $d['type']=='alacak' ? 'arrow-down-left' : 'arrow-up-right'; ?>" 
                                       class="<?php echo $d['type']=='alacak' ? 'text-emerald-500' : 'text-red-500'; ?> mx-auto w-5 h-5"></i>
                                </td>
                                <td>
                                    <div class="font-bold uppercase italic text-xs md:text-sm text-white"><?php echo htmlspecialchars($d['title']); ?></div>
                                    <div class="text-[9px] font-bold uppercase mt-1 <?php echo $is_critical ? 'text-red-500 animate-pulse' : 'text-gray-500'; ?>">
                                        <i data-lucide="calendar" class="inline w-3 h-3 mr-1"></i>
                                        <?php echo date('d.m.Y', strtotime($d['due_date'])); ?> (<?php echo $d['kalan_gun']; ?> gün)
                                    </div>
                                </td>
                                <td class="text-right font-black text-sm md:text-lg <?php echo $d['type']=='alacak' ? 'text-emerald-400' : 'text-red-400'; ?>">
                                    ₺<?php echo number_format($d['amount'], 2, ',', '.'); ?>
                                </td>
                                <td class="text-center">
                                    <div class="flex justify-center gap-1.5">
                                        <a href="?close=<?php echo $d['id']; ?>" onclick="return confirm('Bu borç kapatılıp kasaya gelir/gider olarak aktarılsın mı?')" class="p-2 bg-emerald-500/10 rounded-lg text-emerald-500 hover:bg-emerald-600 hover:text-white transition"><i data-lucide="check" class="w-4 h-4"></i></a>
                                        <button onclick='editDebt(<?php echo json_encode($d); ?>)' class="p-2 bg-indigo-500/10 rounded-lg text-indigo-400 hover:bg-indigo-600 hover:text-white transition"><i data-lucide="edit-3" class="w-4 h-4"></i></button>
                                        <a href="?del=<?php echo $d['id']; ?>" onclick="return confirm('Kayıt tamamen silinsin mi?')" class="p-2 bg-red-500/10 rounded-lg text-red-500 hover:bg-red-600 hover:text-white transition"><i data-lucide="x" class="w-4 h-4"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; if(empty($debts)) echo "<tr><td colspan='4' class='py-10 text-center text-gray-500 italic text-sm'>Henüz aktif bir kayıt bulunmuyor.</td></tr>"; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <div id="addUserModal" class="modal">
        <div class="glass p-6 md:p-8 rounded-[2.5rem] w-full max-w-md">
            <h3 class="text-xl font-black mb-6 text-emerald-500 text-center uppercase italic tracking-tighter">Yeni Ortak Ekle</h3>
            <form method="POST" class="space-y-4">
                <input type="text" name="u_fullname" placeholder="Ad Soyad" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                <input type="text" name="u_name" placeholder="Kullanıcı Adı" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                <input type="password" name="u_pass" placeholder="Şifre" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                <select name="u_share" class="w-full p-4 bg-white/10 border border-white/20 rounded-2xl text-white font-bold text-sm">
                    <option value="1">Verilerimi Paylaş</option>
                    <option value="0">Bağımsız Hesap</option>
                </select>
                <div class="flex gap-3 pt-2">
                    <button type="button" onclick="closeModal('addUserModal')" class="flex-1 py-4 glass rounded-2xl font-bold uppercase text-[10px]">İptal</button>
                    <button type="submit" name="add_new_user" class="flex-1 py-4 bg-emerald-600 rounded-2xl font-black uppercase text-[10px] italic">Kaydet</button>
                </div>
            </form>
        </div>
    </div>

    <div id="userSettingsModal" class="modal">
        <div class="glass p-6 md:p-8 rounded-[2.5rem] w-full max-w-md">
            <h3 class="text-xl font-black mb-6 text-indigo-500 text-center uppercase italic tracking-tighter">Profil Düzenle</h3>
            <form method="POST" class="space-y-4">
                <input type="text" name="n_fullname" value="<?php echo htmlspecialchars($my_name); ?>" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                <input type="text" name="n_username" value="<?php echo htmlspecialchars($user_me['username']); ?>" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                <input type="password" name="n_password" placeholder="Yeni Şifre (Boş bırakılabilir)" class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold text-sm">
                <div class="flex gap-3 pt-2">
                    <button type="button" onclick="closeModal('userSettingsModal')" class="flex-1 py-4 glass rounded-2xl font-bold uppercase text-[10px]">İptal</button>
                    <button type="submit" name="update_profile" class="flex-1 py-4 bg-indigo-600 rounded-2xl font-black uppercase text-[10px] italic">Güncelle</button>
                </div>
            </form>
        </div>
    </div>

    <div id="managePartnersModal" class="modal">
        <div class="glass p-6 md:p-8 rounded-[2.5rem] w-full max-w-md max-h-[80vh] overflow-y-auto">
            <h3 class="text-xl font-black mb-6 text-amber-500 text-center uppercase italic tracking-tighter">Ortak Yönetimi</h3>
            <div class="space-y-3">
                <?php
                $stmt = $pdo->prepare("SELECT * FROM users WHERE shared_id = ?");
                $stmt->execute([$uid]);
                $partners = $stmt->fetchAll();
                foreach ($partners as $p): ?>
                    <div class="p-4 bg-white/5 rounded-2xl border border-white/10 flex items-center justify-between">
                        <div>
                            <p class="text-xs font-bold text-white"><?php echo htmlspecialchars($p['full_name']); ?></p>
                            <span class="text-[8px] font-black uppercase <?php echo $p['status']=='active' ? 'text-emerald-400':'text-red-400';?>">
                                Status: <?php echo $p['status'];?>
                            </span>
                        </div>
                        <div class="flex gap-2">
                            <a href="?toggle_status=<?php echo $p['id']; ?>&st=<?php echo $p['status']; ?>" class="p-2 rounded-lg bg-white/5 text-amber-500"><i data-lucide="refresh-cw" class="w-4 h-4"></i></a>
                            <a href="?del_partner=<?php echo $p['id']; ?>" onclick="return confirm('Silinsin mi?')" class="p-2 rounded-lg bg-red-500/10 text-red-500"><i data-lucide="trash-2" class="w-4 h-4"></i></a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <button onclick="closeModal('managePartnersModal')" class="w-full mt-6 py-4 glass rounded-2xl font-bold uppercase text-[10px]">Kapat</button>
        </div>
    </div>

    <script>
        lucide.createIcons();
        function openModal(id) { document.getElementById(id).style.display = 'flex'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }
        
        function editDebt(d) {
            document.getElementById('fTitle').innerHTML = "<i data-lucide='pencil'></i> Kaydı Düzenle";
            document.getElementById('eId').value = d.id;
            document.getElementById('eType').value = d.type;
            document.getElementById('eTitle').value = d.title;
            document.getElementById('eAmt').value = d.amount;
            document.getElementById('eDate').value = d.due_date;
            document.getElementById('cBtn').classList.remove('hidden');
            lucide.createIcons();
            window.scrollTo({top: 0, behavior: 'smooth'});
        }
        
        function resetForm() {
            document.getElementById('mainForm').reset();
            document.getElementById('eId').value = "";
            document.getElementById('cBtn').classList.add('hidden');
            document.getElementById('fTitle').innerHTML = "<i data-lucide='plus-circle'></i> Kayıt Ekle";
            lucide.createIcons();
        }

        window.onclick = function(e) { if(e.target.classList.contains('modal')) closeModal(e.target.id); }
    </script>
</body>
</html>