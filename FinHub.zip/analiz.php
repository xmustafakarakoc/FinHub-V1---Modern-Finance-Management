<?php 
date_default_timezone_set('Europe/Istanbul');
include 'db.php'; 
checkAuth(); 
$uid = $_SESSION['user_id'];

// --- KULLANICI BİLGİLERİ VE ORTAK HESAP KONTROLÜ ---
$me = $pdo->prepare("SELECT id, shared_id, full_name, username FROM users WHERE id = ?");
$me->execute([$uid]);
$user_me = $me->fetch();
$view_id = ($user_me['shared_id'] > 0) ? $user_me['shared_id'] : $uid;
$my_name = $user_me['full_name']; // Tam isim

// --- HESAP SİLME ---
if (isset($_GET['del_partner'])) {
    $target_id = $_GET['del_partner'];
    $check = $pdo->prepare("SELECT id FROM users WHERE id = ? AND shared_id = ?");
    $check->execute([$target_id, $uid]);
    
    if ($check->rowCount() > 0) {
        $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$target_id]);
        header("Location: analiz.php?msg=Ortak hesap kalıcı olarak silindi"); exit();
    }
}

// --- HESAP DURUMU GÜNCELLEME ---
if (isset($_GET['toggle_status'])) {
    $target_id = $_GET['toggle_status'];
    $new_status = $_GET['st'] == 'active' ? 'suspended' : 'active';
    
    $check = $pdo->prepare("SELECT id FROM users WHERE id = ? AND shared_id = ?");
    $check->execute([$target_id, $uid]);
    
    if ($check->rowCount() > 0) {
        $pdo->prepare("UPDATE users SET status = ? WHERE id = ?")->execute([$new_status, $target_id]);
        header("Location: analiz.php?msg=Hesap durumu güncellendi"); exit();
    }
}

// --- KULLANICI EKLEME ---
$msg = isset($_GET['msg']) ? $_GET['msg'] : "";
if (isset($_POST['add_new_user'])) {
    $fn = $_POST['u_fullname'];
    $u  = $_POST['u_name'];
    $p  = password_hash($_POST['u_pass'], PASSWORD_DEFAULT);
    $shared_id = ($_POST['u_share'] == "1") ? $uid : 0; 

    $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $check->execute([$u]);
    if ($check->rowCount() == 0) {
        $pdo->prepare("INSERT INTO users (full_name, username, password, shared_id, status) VALUES (?, ?, ?, ?, 'active')")->execute([$fn, $u, $p, $shared_id]);
        header("Location: analiz.php?msg=Kullanıcı ($fn) eklendi!"); exit();
    } else { $msg = "Hata: Kullanıcı adı zaten kullanımda."; }
}

// --- PROFİL GÜNCELLEME ---
if (isset($_POST['update_profile'])) {
    $n_fn = $_POST['n_fullname'];
    $n_u  = $_POST['n_username'];
    $n_p  = $_POST['n_password'];
    if(!empty($n_p)) {
        $hashed = password_hash($n_p, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET full_name=?, username=?, password=? WHERE id=?")->execute([$n_fn, $n_u, $hashed, $uid]);
    } else {
        $pdo->prepare("UPDATE users SET full_name=?, username=? WHERE id=?")->execute([$n_fn, $n_u, $uid]);
    }
    header("Location: analiz.php?msg=Profil güncellendi!"); exit();
}

// --- STRATEJİK HESAPLAMA ---
$bugun = (int)date('j'); 
$toplam_gun = (int)date('t');
$kalan_gun = ($toplam_gun - $bugun) + 1;

$stats = $pdo->query("SELECT SUM(CASE WHEN type='gelir' THEN amount ELSE 0 END) as gelir, SUM(CASE WHEN type='gider' THEN amount ELSE 0 END) as gider FROM transactions WHERE user_id = $view_id")->fetch();
$gider = $stats['gider'] ?? 0; 
$gelir = $stats['gelir'] ?? 0;
$bakiye = $gelir - $gider;

$hiz = $gider / max($bugun, 1);
$gunluk_limit = ($bakiye > 0) ? ($bakiye / $kalan_gun) : 0;
$tahmin = $hiz * $toplam_gun;

$kategoriler = $pdo->query("SELECT category, SUM(amount) as toplam FROM transactions WHERE user_id = $view_id AND type='gider' GROUP BY category ORDER BY toplam DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <title>FinHub | Stratejik Analiz</title>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #020306; color: #fff; overflow-x: hidden; }
        .glass { background: rgba(255,255,255,0.02); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.08); }
        .modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.95); z-index: 1000; align-items: center; justify-content: center; padding: 15px; }
        .progress-bar { height: 8px; background: rgba(255,255,255,0.05); border-radius: 10px; overflow: hidden; }
        .progress-fill { height: 100%; transition: width 1s ease; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: #4f46e5; border-radius: 10px; }
        select option { background-color: #02040a !important; color: white !important; }
    </style>
</head>
<body class="flex flex-col md:flex-row min-h-screen">

    <nav class="md:hidden fixed bottom-0 left-0 right-0 glass z-50 flex justify-around p-4 border-t border-white/10">
        <a href="index.php" class="text-gray-400"><i data-lucide="layout-grid"></i></a>
        <a href="analiz.php" class="text-indigo-500"><i data-lucide="line-chart"></i></a>
        <a href="defter.php" class="text-gray-400"><i data-lucide="book-open"></i></a>
        <button onclick="openModal('managePartnersModal')" class="text-amber-400"><i data-lucide="users"></i></button>
    </nav>

    <aside class="hidden md:flex w-64 border-r border-white/10 p-6 flex-col h-screen sticky top-0 bg-[#020306]">
        <div class="text-3xl font-black text-indigo-500 italic mb-10 flex items-center gap-2"><i data-lucide="zap"></i> FinHub.</div>
        <nav class="flex-1 space-y-3">
            <a href="index.php" class="flex items-center gap-3 p-4 text-gray-400 hover:text-white transition font-medium"><i data-lucide="layout-grid"></i> Panel</a>
            <a href="analiz.php" class="flex items-center gap-3 p-4 bg-indigo-600 rounded-2xl text-white shadow-lg font-bold italic transition"><i data-lucide="line-chart"></i> Akıllı Analiz</a>
            <a href="defter.php" class="flex items-center gap-3 p-4 text-gray-400 hover:text-white transition font-medium"><i data-lucide="book-open"></i> Borç Defteri</a>
            
            <div class="pt-6 mt-6 border-t border-white/10 space-y-2">
                <button onclick="openModal('userSettingsModal')" class="w-full flex items-center gap-3 p-4 text-gray-400 hover:text-white transition font-bold italic text-sm text-left"><i data-lucide="settings"></i> Profil Ayarları</button>
                <button onclick="openModal('addUserModal')" class="w-full flex items-center gap-3 p-4 text-emerald-400 hover:bg-emerald-500/10 rounded-2xl transition font-bold italic text-sm text-left"><i data-lucide="user-plus"></i> Kullanıcı Ekle</button>
                <button onclick="openModal('managePartnersModal')" class="w-full flex items-center gap-3 p-4 text-amber-400 hover:bg-amber-500/10 rounded-2xl transition font-bold italic text-sm text-left"><i data-lucide="users"></i> Ortakları Yönet</button>
            </div>
        </nav>
        <div class="mt-auto pt-6 border-t border-white/5 text-[10px] text-gray-600 font-bold uppercase tracking-widest leading-relaxed">Mustafa Karakoç © 2026</div>
    </aside>

    <main class="flex-1 p-4 md:p-10 pb-28 md:pb-10">
        <div class="mb-10 flex justify-between items-center">
            <div>
                <p class="text-gray-500 text-[8px] md:text-[10px] font-black uppercase tracking-[0.3em] mb-1 italic">Analiz ve Öngörü Merkezi</p>
                <h1 class="text-2xl md:text-4xl font-black italic tracking-tighter uppercase text-white">
                    HOŞGELDİN, <span class="text-indigo-500"><?php echo htmlspecialchars($my_name); ?></span>
                </h1>
            </div>
            <div class="flex gap-2">
                <a href="export.php" class="p-3 md:p-5 glass rounded-2xl text-emerald-500 hover:bg-emerald-500/10 transition border border-emerald-500/10" title="Excel Raporu Al">
                    <i data-lucide="file-spreadsheet"></i>
                </a>
                <a href="logout.php" class="p-3 md:p-5 glass rounded-2xl text-red-500 hover:bg-red-500/10 transition border border-red-500/10" title="Güvenli Çıkış">
                    <i data-lucide="log-out"></i>
                </a>
            </div>
        </div>

        <?php if($msg): ?>
            <div class='bg-indigo-500/10 text-indigo-400 p-4 rounded-2xl mb-8 text-center text-sm font-bold border border-indigo-500/20 shadow-xl'><?php echo $msg; ?></div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 md:gap-8 mb-8">
            <div class="lg:col-span-8 glass p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] border-l-8 border-emerald-500 relative">
                <span class="text-[10px] font-black uppercase text-emerald-400 tracking-widest italic">Güvenli Bölge Limiti</span>
                <h2 class="text-3xl md:text-6xl font-black mt-4 mb-4 md:mb-6 italic tracking-tighter text-white">₺<?php echo number_format($gunluk_limit, 2, ',', '.'); ?> <span class="text-sm md:text-xl text-gray-500">/ GÜN</span></h2>
                <p class="text-gray-400 font-medium italic leading-relaxed text-xs md:text-sm">Ay sonu hedefine ulaşmak için günlük bu limitin altında kalmalısın.</p>
                
                <div class="flex flex-row gap-6 md:gap-12 mt-8 md:mt-10 pt-6 md:pt-8 border-t border-white/5">
                    <div>
                        <p class="text-[8px] md:text-[9px] text-gray-600 font-bold uppercase mb-1 italic">Mevcut Hızın</p>
                        <p class="text-sm md:text-xl font-black italic text-white">₺<?php echo number_format($hiz, 2, ',', '.'); ?></p>
                    </div>
                    <div>
                        <p class="text-[8px] md:text-[9px] text-gray-600 font-bold uppercase mb-1 italic">Ay Sonu Tahmini</p>
                        <p class="text-sm md:text-xl font-black italic <?php echo $tahmin>$gelir ? 'text-red-500' : 'text-emerald-500'; ?>">₺<?php echo number_format($tahmin, 2, ',', '.'); ?></p>
                    </div>
                </div>
            </div>

            <div class="lg:col-span-4 glass p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] flex flex-col justify-center items-center text-center">
                <p class="text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-2 italic">Ayın Bitmesine</p>
                <h3 class="text-5xl md:text-7xl font-black italic text-indigo-500 tracking-tighter"><?php echo $kalan_gun; ?></h3>
                <p class="text-[10px] font-black uppercase mt-2 italic text-white">GÜN KALDI</p>
                <div class="w-full mt-6 md:mt-8">
                    <div class="progress-bar"><div class="progress-fill bg-indigo-600" style="width: <?php echo ($bugun/$toplam_gun)*100; ?>%"></div></div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-8">
            <div class="glass p-6 md:p-10 rounded-[2rem] md:rounded-[3rem]">
                <h4 class="text-[10px] font-black uppercase tracking-widest mb-6 md:mb-8 italic text-gray-500">Kategori Bazlı Yoğunluk</h4>
                <div class="space-y-5 md:space-y-6">
                    <?php foreach($kategoriler as $k): 
                        $y = ($gider>0) ? ($k['toplam']/$gider)*100 : 0;
                    ?>
                    <div>
                        <div class="flex justify-between text-[10px] md:text-sm font-bold uppercase mb-2">
                            <span class="italic text-gray-300"><?php echo htmlspecialchars($k['category']); ?></span>
                            <span class="text-indigo-400 font-black">₺<?php echo number_format($k['toplam'], 0, ',', '.'); ?></span>
                        </div>
                        <div class="progress-bar"><div class="progress-fill bg-indigo-500/40" style="width: <?php echo $y; ?>%"></div></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="glass p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] flex flex-col justify-center border-t-4 border-indigo-600/30">
                <i data-lucide="lightbulb" class="w-8 h-8 text-amber-400 mb-4 md:mb-6"></i>
                <h4 class="text-lg md:text-2xl font-black italic uppercase mb-2">FinHub Strateji Notu</h4>
                <div class="text-gray-400 font-medium italic leading-relaxed text-sm md:text-base">
                    <?php if($hiz > $gunluk_limit): ?>
                        Harfiyen dikkat! Günlük harcama hızın (₺<?php echo round($hiz); ?>), güvenli limitini (₺<?php echo round($gunluk_limit); ?>) aşmış durumda. Tasarruf moduna geçmelisin.
                    <?php else: ?>
                        <span class="text-indigo-500 font-bold"><?php echo htmlspecialchars($my_name); ?></span>, finansal disiplinin harika! Ay sonuna tahmini <span class="text-emerald-400 font-bold">₺<?php echo number_format($bakiye - ($hiz * $kalan_gun), 2, ',', '.'); ?></span> net bakiye ile girebilirsin.
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <div id="addUserModal" class="modal">
        <div class="glass p-6 md:p-8 rounded-[2.5rem] w-full max-w-md max-h-[90vh] overflow-y-auto">
            <h3 class="text-xl font-black mb-6 text-emerald-500 text-center uppercase italic tracking-tighter">Yeni User Tanımla</h3>
            <form method="POST" class="space-y-4">
                <div>
                    <label class="text-[9px] font-bold text-gray-500 uppercase ml-2 italic">Ad Soyad</label>
                    <input type="text" name="u_fullname" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl outline-none text-white font-bold text-sm">
                </div>
                <div>
                    <label class="text-[9px] font-bold text-gray-500 uppercase ml-2 italic">Kullanıcı Adı</label>
                    <input type="text" name="u_name" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl outline-none text-white font-bold text-sm">
                </div>
                <div>
                    <label class="text-[9px] font-bold text-gray-500 uppercase ml-2 italic">Şifre</label>
                    <input type="password" name="u_pass" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl outline-none text-white font-bold text-sm">
                </div>
                <div>
                    <label class="text-[9px] font-bold text-gray-500 uppercase ml-2 italic">Hesap Tipi</label>
                    <select name="u_share" class="w-full p-4 bg-white/10 border border-white/20 rounded-2xl text-white font-bold text-sm">
                         <option value="1">Bana Ortak Yap (Verilerimi Görür)</option>
                         <option value="0">Bağımsız Hesap</option>
                    </select>
                </div>
                <div class="flex gap-3 pt-4">
                    <button type="button" onclick="closeModal('addUserModal')" class="flex-1 py-4 glass rounded-2xl font-bold uppercase text-[10px]">İptal</button>
                    <button type="submit" name="add_new_user" class="flex-1 py-4 bg-emerald-600 rounded-2xl font-black uppercase text-[10px] italic shadow-lg">Kaydet</button>
                </div>
            </form>
        </div>
    </div>

    <div id="userSettingsModal" class="modal">
        <div class="glass p-6 md:p-8 rounded-[2.5rem] w-full max-w-md">
            <h3 class="text-xl font-black mb-6 text-indigo-500 text-center uppercase italic tracking-tighter">Profil Düzenle</h3>
            <form method="POST" class="space-y-4">
                <input type="text" name="n_fullname" value="<?php echo htmlspecialchars($my_name); ?>" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl outline-none text-white font-bold text-sm">
                <input type="text" name="n_username" value="<?php echo htmlspecialchars($user_me['username']); ?>" required class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl outline-none text-white font-bold text-sm">
                <input type="password" name="n_password" placeholder="Yeni Şifre (İsteğe Bağlı)" class="w-full p-4 bg-white/5 border border-white/10 rounded-2xl outline-none text-white font-bold text-sm">
                <div class="flex gap-3 pt-4">
                    <button type="button" onclick="closeModal('userSettingsModal')" class="flex-1 py-4 glass rounded-2xl font-bold uppercase text-[10px]">İptal</button>
                    <button type="submit" name="update_profile" class="flex-1 py-4 bg-indigo-600 rounded-2xl font-black uppercase text-[10px] italic">Güncelle</button>
                </div>
            </form>
        </div>
    </div>

    <div id="managePartnersModal" class="modal">
        <div class="glass p-6 md:p-8 rounded-[2.5rem] w-full max-w-md max-h-[85vh] overflow-y-auto">
            <h3 class="text-xl font-black mb-6 text-amber-500 text-center uppercase italic tracking-tighter">Bağlı Ortaklar</h3>
            <div class="space-y-3">
                <?php
                $stmt = $pdo->prepare("SELECT * FROM users WHERE shared_id = ?");
                $stmt->execute([$uid]);
                $partners = $stmt->fetchAll();
                if (count($partners) > 0):
                    foreach ($partners as $p): ?>
                        <div class="p-4 bg-white/5 rounded-2xl border border-white/10 flex items-center justify-between">
                            <div class="max-w-[60%]">
                                <p class="text-sm font-bold text-white truncate"><?php echo htmlspecialchars($p['full_name']); ?></p>
                                <span class="px-2 py-0.5 rounded-md text-[8px] font-black uppercase <?php echo $p['status'] == 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'; ?>">
                                    <?php echo $p['status'] == 'active' ? 'AKTİF' : 'ASKIDA'; ?>
                                </span>
                            </div>
                            <div class="flex gap-2">
                                <a href="?toggle_status=<?php echo $p['id']; ?>&st=<?php echo $p['status']; ?>" 
                                   class="p-3 rounded-xl transition <?php echo $p['status'] == 'active' ? 'bg-amber-500/10 text-amber-500' : 'bg-emerald-500/10 text-emerald-500'; ?>">
                                    <i data-lucide="<?php echo $p['status'] == 'active' ? 'pause-circle' : 'play-circle'; ?>" class="w-4 h-4"></i>
                                </a>
                                <a href="?del_partner=<?php echo $p['id']; ?>" 
                                   onclick="return confirm('Kalıcı olarak silmek istediğine emin misin?')"
                                   class="p-3 rounded-xl bg-red-500/10 text-red-500">
                                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                                </a>
                            </div>
                        </div>
                    <?php endforeach;
                else: ?>
                    <p class="text-center text-gray-500 text-xs italic py-6">Bağlı ortak bulunamadı.</p>
                <?php endif; ?>
            </div>
            <button type="button" onclick="closeModal('managePartnersModal')" class="w-full mt-6 py-4 glass rounded-2xl font-bold uppercase text-[10px]">Kapat</button>
        </div>
    </div>

    <script>
        lucide.createIcons();
        function openModal(id) { document.getElementById(id).style.display = 'flex'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }
        window.onclick = function(e) { if(e.target.classList.contains('modal')) closeModal(e.target.id); }
    </script>
</body>
</html>